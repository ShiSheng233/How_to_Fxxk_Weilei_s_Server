package androidx.core.app;

import android.app.Notification;

public interface NotificationBuilderWithBuilderAccessor {
    Notification.Builder getBuilder();
}
